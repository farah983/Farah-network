
L=['Network','Bio','Programming','Physics','Music']
for i in range(len(L)):
    if L[i].startswith('B'):
        print(L[i])
