def factorial(n):
    if n == 0 or n == 1:
        return 1
    else:
        t= n * factorial(n - 1)
        return t

# ادخال رقم لحساب العاملة له
number = int(input("Enter a non-negative integer: "))

# يجب ان يكون الرقم موجب
if number < 0:
    print("Error: Input must be a non-negative integer")
else:
    # حساب العاملة
    result = factorial(number)
    print("factorial of: ", number, "is: ", result)
