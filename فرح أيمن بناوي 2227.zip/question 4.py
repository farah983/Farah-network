class BankAccount:
    def __init__(self, account_number, account_holder):
        self.account_number = account_number
        self.account_holder = account_holder
        self.balance = 0.0
    
    def deposit(self, amount):
        self.balance += amount
    
    def withdraw(self, amount):
        if self.balance >= amount:
            self.balance -= amount
        else:
            print("الرصيد غير كافٍ.")
    
    def get_balance(self):
        return self.balance
    
    def __str__(self):
        return f"رقم الحساب: {self.account_number}\nاسم صاحب الحساب: {self.account_holder}\nالرصيد الحالي: {self.balance}"


class SavingsAccount(BankAccount):
    def __init__(self, account_number, account_holder, interest_rate):
        super().__init__(account_number, account_holder)
        self.interest_rate = interest_rate
    
    def apply_interest(self):
        interest = self.balance * (self.interest_rate / 100)
        self.balance += interest
    
    def __str__(self):
        return f"رقم الحساب: {self.account_number}\nاسم صاحب الحساب: {self.account_holder}\nالرصيد الحالي: {self.balance}\nمعدل الفائدة: {self.interest_rate}%"


# إنشاء كلاس BankAccount
bank_account = BankAccount("2227", "فرح بناوي ")

# إيداع 1000 دولار
bank_account.deposit(1000)
print(bank_account)

# سحب 500 دولار
bank_account.withdraw(500)
print(bank_account)

# إنشاء كلاس SavingsAccount
savings_account = SavingsAccount("01011", "لجين احمد ", 5)
savings_account.deposit(11000)
# تطبيق الفائدة وطباعة التفاصيل
savings_account.apply_interest()
print(savings_account)
