d={x:x+1 for x in range(11)}
print(d)
